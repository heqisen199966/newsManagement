package hqs.probation;

import java.time.LocalDate;
import hqs.Service.Aminstratorinfor.AdminstratorinforServiceImpl;
import hqs.Service.Comments.CommentsServiceImpl;
import hqs.Service.NewsRoles.NewsRolesServiceImpl;
import hqs.Service.NewsScriptService.NewsScriptServiceImpl;
import hqs.Service.PostNews.PostNewsServiceImpl;
import hqs.Service.UserInformation.UserInformationServiceImpl;
import hqs.entity.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.sound.midi.Soundbank;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootTest
class ProbationApplicationTests {

    @Autowired
    private NewsRolesServiceImpl newsRolesServiceImpl;

    @Autowired
    private AdminstratorinforServiceImpl adminstratorinforService;

    @Autowired
    private UserInformationServiceImpl userInformationService;

    @Autowired
    private NewsScriptServiceImpl newsScriptService;

    @Autowired
    private PostNewsServiceImpl postNewsService;

    @Autowired
    private CommentsServiceImpl commentsService;
    @Test
    void contextLoads() {

       newsRolesServiceImpl.createNewsRoles(new NewsRoles("3","admin"));

    }


    @Test
    void createAdmin() {


        NewsRoles role = new NewsRoles("admin");

        Adminstratorinfor adminstratorinfor = new Adminstratorinfor("123","123","133");
        adminstratorinforService.createAdminstratorinfor(role,adminstratorinfor);
        System.out.println(role.getUsers_Id());
        System.out.println(adminstratorinfor.getUsers_Id());

    }


    @Test
    void createUser() {


        NewsRoles role = new NewsRoles("user");

        UserInformation userInformation = new  UserInformation();
        userInformation.setUser_Account("123");
        userInformation.setUser_Name("3123");
        userInformation.setUser_Pwd("123123");
        userInformation.setUser_IsComment(true);
        userInformation.setUser_Status(false);
        userInformationService.createUserInformation(role,userInformation);
        System.out.println(userInformation.getUsers_Id());
    }

    @Test
    void createScript() {
        NewsScript newsScript = new NewsScript();
        newsScript.setNews_Content("123");
        newsScript.setClipsPath("333");
        newsScript.setNews_Editor("123123");
        newsScript.setNews_Headline("12312321");
        newsScript.setIsPost(false);
        newsScript.setOutline("1231231");
        newsScript.setPicPath("123123");
        newsScript.setNews_HandlingDate(new Date());

        newsScriptService.createNewsScript(newsScript);
        System.out.println(newsScript.getNews_Id());
    }


    @Test

    void createPostNews() {
        PostNews postNews = new PostNews();
//        postNews.setUsers_Id("047be9572ecd49f1b1f7f9af708577ec");
//        postNews.setNews_Id(1);
        postNews.setNews_Genre("123123");
        postNews.setNews_Section("123");
        postNews.setNews_Views(3);
        postNews.setNews_PostDate(new Date());
       postNews.setNews_KeyWords("123123");
           postNews.setNews_Sequence(3);
     // postNewsService.createPostNews("047be9572ecd49f1b1f7f9af708577ec",1,postNews);
        System.out.println(postNews);
    }


    @Test
    public  void createComments()
    {
        Comments comments = new Comments();
        commentsService.creatComments("6cf4b6eb7b804b76888d464bd497bada",3,comments);
        System.out.println(comments);
    }


    @Test
    public void getAllNewsScript()
    {
        List<NewsScript> d = new ArrayList<>();
        d=newsScriptService.getAllNewsScript();
        for (NewsScript sc :
                d) {
            System.out.println(sc);
        }
    }

    @Test
    public void getUserId()
    {
  UserInformation ob = userInformationService.getUsersByAP("dj474097639","xiaosen199966");
      //   Adminstratorinfor ob =    adminstratorinforService.getAdminByAP("123","123");
        System.out.println(ob);
    }

    @Test
    public void getRole()
    {

        String role =   newsRolesServiceImpl.getRole("047be9572ecd49f1b1f7f9af708577ec");
        System.out.println(role);
    }


    @Test
    public  void getAdminByID()
    {
      UserInformation userInformation = userInformationService.getUserByID("9017bc7f9ec94f2b8f0aef7db5128782");
        System.out.println(userInformation);
    }

    @Test
    public void updateScriptByID()
    {
        NewsScript newsScript = new NewsScript();
        newsScript.setNews_Id(8);
        newsScript.setNews_Editor("我啊");
        newsScript.setNews_Headline("wwww");
        Integer x = newsScriptService.updateNewsScriptById(newsScript);
        System.out.println(x);

    }
    @Test
    public void getPostNewSByID()
    {
        PostNews postNews = postNewsService.getPostNewsByNewsID(1);
        System.out.println(postNews);
    }

    @Test
    public  void   updatePostNewsByID()
    {
        PostNews postNews = new PostNews();
        postNews.setNews_Id(2);
        postNews.setNews_Views(100);
        Integer x = postNewsService.updatePostNewsByID(postNews);
        System.out.println(x);
    }

    @Test
    public  void markIsPost()
    {
        newsScriptService.markIsPost(1,false);
    }

    @Test
    public void  getAllCommentsV2(){
        List<UserAndComments> x = commentsService.getAllCommentsV2();
        for (UserAndComments u:
             x) {
            System.out.println(u);

        }
    }
    @Test
    public void getPostNewsByGenre()
    {
        List<ShowingNews> showingNews = postNewsService.getPostNewsByGenre("policy");
        for (ShowingNews s :
                showingNews) {
            System.out.println(s);
        }
    }
    @Test
    public void addViews()
    {
        Integer x = postNewsService.addViewsByID(6);
        System.out.println(x);

    }

    @Test
    public void  getAllCommentsV3(){
        List<UserAndComments> x = commentsService.getAllCommentsByNewsId(2);
        for (UserAndComments u:
                x) {
            System.out.println(u);
        }
    }
    @Test
    public void getHomePageNews()
    {
        List<ShowingNews> showingNews  = postNewsService.getHomePagePostNews("homepage");
        System.out.println(showingNews);
    }

    @Test
    public void checkIsComment()
    {
          boolean a = userInformationService.checkAbleToComment("be8130cbcf0248cb9231e13918bab659");
        System.out.println(a);
    }

    @Test
    public  void getNewsByHeadLine()
    {
        List<ShowingNews> showingNews = postNewsService.getNewsByHeadLine("一定");
        for (ShowingNews s:
             showingNews) {
            System.out.println(s);
        }
    }
    @Test
    public  void checkIfAccountUnique()
    {
        boolean x = userInformationService.checkIfAccountUnique("321");
        System.out.println(x);
    }
}
