package hqs;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//主入口文件，放在hqs之下，自动扫描对应包及其下面的包
/*
    规定:
         1.使用端口号为8888/newsManagement开始访问
         2.新闻图片写死存在当前项目位置的static/NewsPic中，上传了东西需要重新部署才能访问
         3.前端直接使用src地址访问图片

 */
@SpringBootApplication
@MapperScan("hqs/Dao")//扫描Dao包下的mapper接口
public class ProbationApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProbationApplication.class, args);
    }

}
