package hqs.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import hqs.Service.Aminstratorinfor.AdminstratorinforServiceImpl;
import hqs.Service.Comments.CommentsServiceImpl;
import hqs.Service.NewsRoles.NewsRolesService;
import hqs.Service.NewsScriptService.NewsScriptServiceImpl;
import hqs.Service.PostNews.PostNewsServiceImpl;
import hqs.Service.UserInformation.UserInformationServiceImpl;
import hqs.entity.Adminstratorinfor;
import hqs.entity.NewsScript;
import hqs.entity.PostNews;
import hqs.entity.UserInformation;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

//用于前台发送过来要更新的请求
@RestController
@CrossOrigin
public class UpdateController {
    @Autowired
    private AdminstratorinforServiceImpl adminstratorinforService;

    @Autowired
    private NewsRolesService newsRolesService;
    @Autowired//注入普通用户服务
    private UserInformationServiceImpl userInformationService;

    @Autowired//注入新闻稿的服务
    private NewsScriptServiceImpl newsScriptService;

    @Autowired//注入发布新闻的服务
    private PostNewsServiceImpl postNewsService;

    @Autowired
    private CommentsServiceImpl commentsService;

    @Resource(name = "conMap")//获取IOC容器中的map
    private Map<String,Object> conMap;


    //使用rest风格的put请求
    @PutMapping("/modifyNewsScript")
    public  Map<String,Object> modifyNewsScript(NewsScript newsScript,@RequestPart(name = "pic",required = false) MultipartFile picFile) throws IOException {
        newsScript.setNews_HandlingDate(new Date());
        String savePath = "E:/Idea项目/newsManagement/src/main/resources/static/NewsPic/";
        //我们拿的时候以 地址newsManagement + NewsPic/图片文件名
        String getPath = "NewsPic/";
        if( picFile!=null && !picFile.isEmpty())
        {
            //使用唯一的ID
            String picId =   UUID.randomUUID().toString().replace("-", "");
            String extension = FilenameUtils.getExtension(picFile.getOriginalFilename());
            String wholeName = picId+"."+extension;
            picFile.transferTo(new File(savePath,wholeName));
            newsScript.setPicPath(getPath+wholeName);
        }
        conMap.put("newsUpdate",false);
        Integer x =  newsScriptService.updateNewsScriptById(newsScript);
        if(x!=null)
        {
            conMap.put("newsUpdate",true);
        }
        return conMap;
    }

    @PutMapping("/updatePostingNews")
    public Map<String,Object> updatePostingNews(PostNews postNews, HttpServletRequest request)
    {
        String id = (String) request.getSession().getAttribute("uuid");
        //对于User_ID，在session中拿出来，因为能进入后台要先登录，登录之后有session,当然BUG除外
        postNews.setUsers_Id(id);
        postNews.setNews_PostDate(new Date());
        Integer x = postNewsService.updatePostNewsByID(postNews);
        conMap.put("updateStatus",false);
        if(x!=null)
        {
            conMap.put("updateStatus",true);
        }
        return conMap;
    }


    @PutMapping("/updatePeopleInfor/{isAdmin}")
    public Map<String,Object>updatePeopleInfor(@PathVariable("isAdmin") Boolean isAdmin,@RequestBody Map<String,Object> infor)
    {
        Integer check = null;
        if(!isAdmin)
        {
            UserInformation userInformation = JSON.parseObject(JSON.toJSONString(infor.get("fd")),new TypeReference<>() { });
            check = userInformationService.updateUserByID(userInformation);

        }else {
            Adminstratorinfor adminstratorinfor = JSON.parseObject(JSON.toJSONString(infor.get("fd")),new TypeReference<>() { });
            check = adminstratorinforService.updateAdminByID(adminstratorinfor);
        }
        conMap.put("status",false);
        if(check!=null)
        {
            conMap.put("status",true);
        }

        return conMap;
    }

    @PutMapping("/addView/{news_Id}")
    public Map<String,Object>addView(@PathVariable("news_Id") Integer news_Id)
    {
        Integer x = postNewsService.addViewsByID(news_Id);
        conMap.put("isAddView",false);
        if(x!=null)
        {
            conMap.put("isAddView",true);

        }
        return conMap;
    }
}
