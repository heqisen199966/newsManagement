package hqs.controller;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

//这个用于测试前端数据用
@RestController
@CrossOrigin
public class TestController {


    @PostMapping("/postOne")
    public  Map<String,Object> postOne(@RequestBody Map<String,Object> data)
    {

        System.out.println(data);

        return  data;
    }
}
