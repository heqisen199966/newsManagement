package hqs.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import hqs.Service.Aminstratorinfor.AdminstratorinforServiceImpl;
import hqs.Service.Comments.CommentsServiceImpl;
import hqs.Service.NewsScriptService.NewsScriptServiceImpl;
import hqs.Service.PostNews.PostNewsServiceImpl;
import hqs.Service.UserInformation.UserInformationServiceImpl;
import hqs.entity.*;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.Console;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

//这里是关于创建的控制器
@RestController
@CrossOrigin
//使用rest风格的提交方式: get->查询，post新增，put->修改,delete->删除
//创建用户名不能重复，但是还没写具体的业务逻辑
public class CreateController {

    //注入管理员服务
    @Autowired
    private AdminstratorinforServiceImpl adminstratorinforService;

    @Autowired//注入普通用户服务
    private UserInformationServiceImpl userInformationService;

    @Autowired//注入新闻稿的服务
     private NewsScriptServiceImpl newsScriptService;

    @Autowired//注入发布新闻的服务
     private PostNewsServiceImpl postNewsService;

    @Autowired
      private CommentsServiceImpl commentsService;

   @Resource(name = "conMap")//获取IOC容器中的map
    private Map<String,Object> conMap;

    //使用get方法请求,在地址上我们设置要
    @PostMapping("/createAdmin")
    //自动封装，注意属性名字要一致
    public String createAdmin(Adminstratorinfor adminstratorinfor) {
    //既然这里是创建管理员了，那么默认设置角色为admin
        adminstratorinforService.createAdminstratorinfor(new NewsRoles("admin"),adminstratorinfor);
         //跳转之后再做
          return "OK";
    }

    @PostMapping("/creatUser")
    //创建用户
    //前台给的是一个对象，对象里某个属性是名字叫userInformation
    public Map<String,Object> createUser( @RequestBody Map<String,Object> frontData)
    {
        //这里使用工具将JSON对象转化为我们需要的类
        UserInformation userInformation = JSON.parseObject(JSON.toJSONString(frontData.get("userInformation")),new TypeReference<UserInformation>() { });
       String account = userInformation.getUser_Account();
       //先检查账号唯一性
        conMap.put("status",false);
        conMap.put("reason","账号重复");
        if(!userInformationService.checkIfAccountUnique(account))
        {
         userInformationService.createUserInformation(new NewsRoles("user"),userInformation);
         conMap.put("status",true);
        }

        //跳转之后再做
        return  conMap;
    }


    //注意上传只能使用post
    @PostMapping("/createScript")
    //这里应该接受一个图片，然后将图片存储到计算机中，再把它的地址写进去，同理视频也是，后面再搞
    public Map<String, Object> createScript(NewsScript newsScript, @RequestPart(name = "pic",required = false) MultipartFile picFile, @RequestPart( name="clip",required = false) MultipartFile clipFile, HttpServletRequest request) throws IOException {
        //注意上传之后不能马上访问要再次部署才能访问，现在还没找到哪个办法自动部署的，全都得手动部署
        //在这里写入时间
        newsScript.setNews_HandlingDate(new Date());
        newsScript.setIsPost(false);//默认不提交

        //将新闻图片放到服务器中的NewsPic中，注意这里的路径不能随意改，本来想拿到一个动态路径，但是它部署到了C盘上，
        //还解决不了
     String savePath = "E:/Idea项目/newsManagement/src/main/resources/static/NewsPic/";
     //我们拿的时候以 地址newsManagement + NewsPic/图片文件名
     String getPath = "NewsPic/";
     if( picFile!=null && !picFile.isEmpty())
        {
            //使用唯一的ID
            String picId =   UUID.randomUUID().toString().replace("-", "");
            String extension = FilenameUtils.getExtension(picFile.getOriginalFilename());
            String wholeName = picId+"."+extension;
            picFile.transferTo(new File(savePath,wholeName));
            newsScript.setPicPath(getPath+wholeName);
        }
        if(clipFile!=null && !clipFile.isEmpty())
        {
            String clipFileId =   UUID.randomUUID().toString().replace("-", "");
            String extension = FilenameUtils.getExtension(clipFile.getOriginalFilename());
            String wholeName = clipFileId+"."+extension;
            clipFile.transferTo(new File(savePath,wholeName));
            newsScript.setClipsPath(getPath+wholeName);
        }
        System.out.println(newsScript);
        newsScriptService.createNewsScript(newsScript);
        conMap.put("status",false);
        if(newsScript.getNews_Id()!=null)
        {
          conMap.put("status",true);//创建成功
        }
        return conMap;
        //之后再做跳转

    }



    @PostMapping("/createPostNews")
    public Map<String, Object> createPostNews(PostNews postNews, HttpServletRequest request)
    {
        //修改新闻稿发布状态，添加发布稿
        String id = (String) request.getSession().getAttribute("uuid");
        //对于User_ID，在session中拿出来，因为能进入后台要先登录，登录之后有session,当然BUG除外
        postNews.setUsers_Id(id);
        //阅读量初始化为0
        postNews.setNews_Views(0);
      //  System.out.println(postNews);
     Integer x =   newsScriptService.markIsPost(postNews.getNews_Id(),true);
        postNewsService.createPostNews(postNews);
       // System.out.println(postNews);
      // postNewsService.createPostNews(postNews);
        conMap.put("postStatus",false);
        if (x!=null)
        {
            conMap.put("postStatus",true);
        }
       //之后再跳转
       return conMap;
    }


    @PostMapping("/createComments/{News_Id}")
    public  Map<String,Object> createComments(@PathVariable("News_Id") Integer news_Id,Comments comments,HttpServletRequest request)
    {
//  评论直接在session中过去id,要记得登录
    //还没搞用户是否禁言
        HttpSession session  = request.getSession();
        String users_Id = (String)session.getAttribute("uuid");
        conMap.put("isAddComment",false);
        conMap.put("reason","添加失败");
        //看看是否禁言
        if(!userInformationService.checkAbleToComment(users_Id))
        {
            conMap.put("reason","用户已被禁言");
            return  conMap;
        }
        Integer x =    commentsService.creatComments(users_Id,news_Id,comments);

     if (x!=null)
     {
         conMap.put("isAddComment",true);
     }
        return conMap;
    }
}
