package hqs.controller;

import hqs.Service.NewsRoles.NewsRolesServiceImpl;
import hqs.entity.NewsRoles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@Controller
@CrossOrigin//表示跨域请求
//对于 NewsRoles目前只需要创建即可
//这里不需要使用，创建角色需要依赖其他
public class NewsRolesController {

    @Autowired
    private NewsRolesServiceImpl newsRolesServiceImpl;
    //这里是添加
    //创建时需要在地址栏带上角色
    //使用get方法请求
    @GetMapping("/createNewsRoles/{role}")
    public String createNewsRoles(@PathVariable("role") String role)
    {
        NewsRoles newsRoles = new NewsRoles();
        newsRoles.setRole(role);
        newsRolesServiceImpl.createNewsRoles(newsRoles);
        //返回唯一ID
        //这里的跳转之后再做
        return "";
    }
}
