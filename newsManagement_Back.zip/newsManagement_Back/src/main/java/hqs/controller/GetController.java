package hqs.controller;

import hqs.Service.Aminstratorinfor.AdminstratorinforServiceImpl;
import hqs.Service.Comments.CommentsServiceImpl;
import hqs.Service.NewsScriptService.NewsScriptServiceImpl;
import hqs.Service.PostNews.PostNewsServiceImpl;
import hqs.Service.UserInformation.UserInformationServiceImpl;
import hqs.entity.PostNews;
import hqs.entity.ShowingNews;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//返回值均为响应页面
@RestController
@CrossOrigin
public class GetController {
    @Autowired
    private AdminstratorinforServiceImpl adminstratorinforService;

    @Autowired//注入普通用户服务
    private UserInformationServiceImpl userInformationService;

    @Autowired//注入新闻稿的服务
    private NewsScriptServiceImpl newsScriptService;

    @Autowired//注入发布新闻的服务
    private PostNewsServiceImpl postNewsService;

    @Autowired
    private CommentsServiceImpl commentsService;

    @Resource(name = "conMap")//获取IOC容器中的map
    private Map<String,Object> conMap;


    @GetMapping("/getAllNewsScript")
    //将数据封装成返回去
    public Map<String,Object> getAllNewsScript()
    {

        conMap.put("newsScript",newsScriptService.getAllNewsScript());
        return conMap;
    }

    @GetMapping("/getAllAdminstratorinfor")
    public Map<String,Object> getAllAdminstratorinfor()
    {

        conMap.put("Adminstratorinfor",adminstratorinforService.getAllAdminstratorinfor());
        return conMap;
    }

    @GetMapping("/getAllUserInformation")
    public Map<String,Object> getAllUserInformationr()
    {

        conMap.put("UserInformation",userInformationService.getAllusersinformation());
        return conMap;
    }


    @GetMapping("/getAllPostNews")
    public Map<String,Object> getAllPostNews()
    {

        conMap.put("PostNews",postNewsService.getAllPostNews());
        return conMap;
    }

    @GetMapping("/getPostNewsByID/{id}")
    public  Map<String,Object> getPostNewsByID(@PathVariable("id") Integer id)
    {
        PostNews postNews = postNewsService.getPostNewsByNewsID(id);
        conMap.put("postNews",postNews);
        return conMap;
    }


    @GetMapping("/getAllComments")
    public Map<String,Object> getAllComments()
    {

        conMap.put("AllComments",commentsService.getAllComments());
        return conMap;
    }

    @GetMapping("/getUsersComments")
    public Map<String,Object> getUsersComments()
    {
        conMap.put("usersComments",commentsService.getAllCommentsV2());
        return conMap;
    }

    @GetMapping("/getPostNewsByGnere/{Gnere}")
    public Map<String,Object> getPostNewsByGnere(@PathVariable("Gnere") String genre)
    {
        List<ShowingNews>  postNews =postNewsService.getPostNewsByGenre(genre);
        conMap.put("postNews",postNews);
        return conMap;
    }

    @GetMapping("/getCommentsByNewsId/{News_Id}")
    private Map<String,Object> getCommentsByNewsId(@PathVariable("News_Id") Integer News_Id)
    {
        conMap.put("comments",commentsService.getAllCommentsByNewsId(News_Id));
        return conMap;
    }

    //虽然是拿首页，这里扩展为按照区域来拿
    @GetMapping("/getHomePageNews/{section}")
    public  Map<String,Object>getHomePageNews(@PathVariable("section") String section)
    {
//        System.out.println(section);
        conMap.put("homepageNews",postNewsService.getHomePagePostNews(section));
        return conMap;

    }

    //搜索，根据新闻标题，简介，关键字
    @GetMapping("/getNewsByHOK/{HOK}")
    public Map<String,Object>getNewsByHOK(@PathVariable("HOK") String HOK)
    {
        conMap.put("searchingStatus",false);
        List<ShowingNews> showingNews = postNewsService.getNewsByHeadLine(HOK);
        if (showingNews!=null)
        {
            conMap.put("searchingData",showingNews);
            conMap.put("searchingStatus",true);
        }
        return conMap;

    }
}
