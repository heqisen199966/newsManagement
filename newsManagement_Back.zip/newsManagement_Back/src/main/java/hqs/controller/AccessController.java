package hqs.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import hqs.Service.Aminstratorinfor.AdminstratorinforServiceImpl;
import hqs.Service.Comments.CommentsServiceImpl;
import hqs.Service.NewsRoles.NewsRolesService;
import hqs.Service.NewsRoles.NewsRolesServiceImpl;
import hqs.Service.NewsScriptService.NewsScriptServiceImpl;
import hqs.Service.PostNews.PostNewsServiceImpl;
import hqs.Service.UserInformation.UserInformationServiceImpl;
import hqs.entity.Adminstratorinfor;
import hqs.entity.FrontData;
import hqs.entity.UserInformation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

//这里是登录验证等，需要后端验证某些数据
@RestController
@CrossOrigin
public class AccessController {
    @Autowired
    private AdminstratorinforServiceImpl adminstratorinforService;

    @Autowired
    private  NewsRolesService newsRolesService;
    @Autowired//注入普通用户服务
    private UserInformationServiceImpl userInformationService;

    @Autowired//注入新闻稿的服务
    private NewsScriptServiceImpl newsScriptService;

    @Autowired//注入发布新闻的服务
    private PostNewsServiceImpl postNewsService;

    @Autowired
    private CommentsServiceImpl commentsService;

    @Resource(name = "conMap")//获取IOC容器中的map
    private Map<String,Object> conMap;


    //用户登录，同时把它写进session里面
   @PostMapping("/userLogin")
    public Map<String,Object> userLogin(@RequestBody Map<String,Object> frontData, HttpServletRequest request)
   {
       //JSON变为对象，这里有更好的方法转为对象，还没找到
       //这里获取账号和密码，去对应的表找是否有这个人，有就将它放在session中，之后的异步向session拿
       //BUG先不搞，找到就返回true,错误就false,哪个东西错了就先不管
       String account = JSON.parseObject(JSON.toJSONString(frontData.get("account")),new TypeReference<String>() { });
      String pwd = JSON.parseObject(JSON.toJSONString(frontData.get("pwd")),new TypeReference<String>() { });

       String status="false";
       //直接拿一个对象过来
       Adminstratorinfor adminstratorinfor = adminstratorinforService.getAdminByAP(account,pwd);
       UserInformation userInformation =  userInformationService.getUsersByAP(account,pwd);
       String name=  null;
       String role = null;
       String uuid = null;//唯一ID

      if(adminstratorinfor!=null)
      {
          name = adminstratorinfor.getAdmin_Name();
          role="admin";
          uuid=adminstratorinfor.getUsers_Id();
      }
      else if(userInformation != null)
      {
          //封号状态就不能登录
          if(!userInformation.isUser_Status())
          {
                conMap.put("status",false);
                conMap.put("reason","封号中");
                return conMap;
          }
          name = userInformation.getUser_Name();
          role= "user";
          uuid= userInformation.getUsers_Id();


      }
       HttpSession session = request.getSession();
        session.setAttribute("role",role);//保存角色
       session.setAttribute("name",name);//保存用户名
       session.setAttribute("uuid",uuid);
       if(role!=null)
     {
         status="true";

     }
      //返回状态
       conMap.put("status",status);
       conMap.put("reason","密码或账号错误");
      //角色放在session中
      return conMap;
   }

   //获取角色和用户名
   @GetMapping("/getRole")
    public  Map<String,Object> getRoleAndName(HttpServletRequest request)
   {
      String role = (String) request.getSession().getAttribute("role");

     String name = (String) request.getSession().getAttribute("name");
      conMap.put("role",role);
      conMap.put("name",name);
       return  conMap;
   }

   //直接返回一个整个用户信息算了
    @GetMapping("/getGuy")
    public Map<String,Object> getGuy(HttpServletRequest request)
    {
        //查询用户前先知道它的角色再去SQL找
        HttpSession session = request.getSession();
        String role= null;
        role = (String) session.getAttribute("role");
        if(role==null)
        {
            conMap.put("guy",null);
            return conMap;
        }
        else {
            String uuid = (String) session.getAttribute("uuid");
            if(role.equals("admin"))
            {
                Adminstratorinfor adminstratorinfor = adminstratorinforService.getAdminByID(uuid);
                conMap.put("guy",adminstratorinfor);
            }
            else {
                UserInformation userInformation =userInformationService.getUserByID(uuid);
                conMap.put("guy",userInformation);
            }
        }
        return conMap;
    }
}
