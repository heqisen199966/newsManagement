package hqs.controller;

import hqs.Service.Aminstratorinfor.AdminstratorinforServiceImpl;
import hqs.Service.Comments.CommentsServiceImpl;
import hqs.Service.NewsRoles.NewsRolesService;
import hqs.Service.NewsScriptService.NewsScriptServiceImpl;
import hqs.Service.PostNews.PostNewsServiceImpl;
import hqs.Service.UserInformation.UserInformationServiceImpl;
import hqs.entity.PostNews;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.sql.SQLOutput;
import java.util.Map;

@RestController
@CrossOrigin
public class DeleteController {

    @Autowired
    private AdminstratorinforServiceImpl adminstratorinforService;

    @Autowired
    private NewsRolesService newsRolesService;
    @Autowired//注入普通用户服务
    private UserInformationServiceImpl userInformationService;

    @Autowired//注入新闻稿的服务
    private NewsScriptServiceImpl newsScriptService;

    @Autowired//注入发布新闻的服务
    private PostNewsServiceImpl postNewsService;

    @Autowired
    private CommentsServiceImpl commentsService;

    @Resource(name = "conMap")//获取IOC容器中的map
    private Map<String,Object> conMap;

    //取消发布
    @DeleteMapping("/noPost/{News_Id}")
    public Map<String,Object> noPost(@PathVariable("News_Id") Integer News_Id)
    {
        //修改状态
        Integer x =   newsScriptService.markIsPost(News_Id,false);
        Integer y = postNewsService.deletePostNewsById(News_Id);
        //撤下对应的新闻
        conMap.put("deleteStatus",false);
        if (x!=null && y!=null)
        {
            conMap.put("deleteStatus",true);
        }

        return conMap;
    }

    @DeleteMapping("/deleteComment/{Users_Id}/{News_Id}/{uuid}")
    public Map<String,Object> deleteComment(@PathVariable("Users_Id") String Users_Id,@PathVariable("News_Id") Integer News_Id,@PathVariable("uuid") String uuid)
    {
//        System.out.println(Users_Id);
//        System.out.println(News_Id);
        Integer x = commentsService.deleteComment(Users_Id,News_Id,uuid);
        conMap.put("isDeleted",false);
        if(x!=null)
        {
            conMap.put("isDeleted",true);
        }
        return conMap;
    }


}
