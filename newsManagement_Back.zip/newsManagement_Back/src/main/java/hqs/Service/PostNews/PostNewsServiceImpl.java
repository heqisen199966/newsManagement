package hqs.Service.PostNews;

import hqs.Dao.PostNewsDao;
import hqs.entity.PostNews;
import hqs.entity.ShowingNews;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.sql.In;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class PostNewsServiceImpl implements PostNewsService{

   @Autowired//调用数据库服务
   private PostNewsDao postNewsDao;

   //我们创建它的时候需要控制器给它用户ID，新闻的ID，至于怎么给看控制器调用了
    @Override
    public void createPostNews( PostNews postNews) {
            postNews.setNews_PostDate(new Date());//日期自己写
            postNewsDao.createPostNews(postNews);
    }

    @Override
    public List<PostNews> getAllPostNews() {
        return postNewsDao.getAllPostNews();
    }

    @Override
    public PostNews getPostNewsByNewsID(Integer newsId) {
       try {
           return postNewsDao.getPostNewsByNewsID(newsId);
       }catch (Exception e)
       {
           System.out.println(e);
           return null;
       }
    }

    @Override
    public Integer updatePostNewsByID(PostNews postNews) {
       try{
           return postNewsDao.updatePostNewsByID(postNews);
       }catch ( Exception e)
       {
           System.out.println(e);
           return null;
       }
    }

    @Override
    public Integer deletePostNewsById(Integer News_Id) {
        try {
            return postNewsDao.deletePostNewsById(News_Id);
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<ShowingNews> getPostNewsByGenre(String genre) {
        try {
            return postNewsDao.getPostNewsByGenre(genre);
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Integer addViewsByID(Integer News_Id) {
        try{
            return postNewsDao.addViewsByID(News_Id);
        }catch (Exception e )
        {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<ShowingNews> getHomePagePostNews(String homepage) {
        try {
            return  postNewsDao.getHomePagePostNews(homepage);
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<ShowingNews> getNewsByHeadLine(String HeadLine) {
        try {
            return postNewsDao.getNewsByHeadLine(HeadLine);

        }catch (Exception e)

        {
            System.out.println(e);
            return null;
        }
    }
}
