package hqs.Service.PostNews;

import hqs.entity.PostNews;
import hqs.entity.ShowingNews;
import org.springframework.data.relational.core.sql.In;

import java.util.List;

public interface PostNewsService {
    //创建的时候我们需要给出用户的ID，加上这个新闻的id
    public  void createPostNews(PostNews postNews);
    public List<PostNews> getAllPostNews();
    public PostNews getPostNewsByNewsID(Integer newsId);
    public Integer updatePostNewsByID(PostNews postNews);
    public  Integer deletePostNewsById(Integer News_Id);
    public List<ShowingNews> getPostNewsByGenre(String genre);

    public   Integer addViewsByID(Integer  News_Id);

    public List<ShowingNews> getHomePagePostNews(String homepage);
    public List<ShowingNews> getNewsByHeadLine(String HeadLine);
}
