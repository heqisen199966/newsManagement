package hqs.Service.Aminstratorinfor;

import hqs.entity.Adminstratorinfor;
import hqs.entity.NewsRoles;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AdminstratorinforService {
    public void createAdminstratorinfor(NewsRoles newsRoles,Adminstratorinfor adminstratorinfor);
    public List<Adminstratorinfor> getAllAdminstratorinfor();
    public Adminstratorinfor getAdminByAP( String account, String pwd);
    public  Adminstratorinfor getAdminByID(String id);
    public Integer updateAdminByID(Adminstratorinfor adminstratorinfor);
}
