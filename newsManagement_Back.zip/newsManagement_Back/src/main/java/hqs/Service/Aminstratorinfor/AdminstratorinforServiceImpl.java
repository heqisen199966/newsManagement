package hqs.Service.Aminstratorinfor;

import hqs.Dao.AminstratorinforDao;
import hqs.Service.NewsRoles.NewsRolesServiceImpl;
import hqs.entity.Adminstratorinfor;
import hqs.entity.NewsRoles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


//创建管理员，这里得先创建NewRoles
@Service
public class AdminstratorinforServiceImpl implements  AdminstratorinforService{

    @Autowired//注入创建Roles角色的服务
    private NewsRolesServiceImpl newsRolesService;

    @Autowired
    private AminstratorinforDao   aminstratorinforDao;

    @Override
    public void createAdminstratorinfor(NewsRoles newsRoles, Adminstratorinfor adminstratorinfor) {
        newsRolesService.createNewsRoles(newsRoles);
        //我们调用创建角色的服务，然后获取它的自动生成的UUID，再创建admin角色
        String User_id =  newsRoles.getUsers_Id();
         adminstratorinfor.setUsers_Id(User_id);
         aminstratorinforDao.createAminstratorinfor(adminstratorinfor);
    }

    @Override
    public List<Adminstratorinfor> getAllAdminstratorinfor() {
        return aminstratorinforDao.getAllAdminstratorinfor();
    }

    @Override
    public Adminstratorinfor getAdminByAP(String account, String pwd) {
        //找不到就返回null
        try {
            return aminstratorinforDao.getAdminByAP(account,pwd);
        }catch (Exception e
        ){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Adminstratorinfor getAdminByID(String id) {
        try{
            return aminstratorinforDao.getAdminByID(id);
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Integer updateAdminByID(Adminstratorinfor adminstratorinfor) {
       try {
           return aminstratorinforDao.updateAdminByID(adminstratorinfor);
       }catch (Exception e)
       {
           System.out.println(e);
           return null;
       }
    }
}
