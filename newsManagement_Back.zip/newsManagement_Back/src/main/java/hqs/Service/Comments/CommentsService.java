package hqs.Service.Comments;

import hqs.entity.Comments;
import hqs.entity.UserAndComments;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CommentsService {
    //评论也是需要用户ID和新闻ID
    public Integer  creatComments(String Users_Id ,Integer News_Id, Comments comments);
    public List<Comments> getAllComments();
    public List<UserAndComments> getAllCommentsV2();
    public Integer deleteComment( String Users_Id,Integer News_Id,String uuid);
    public List<UserAndComments> getAllCommentsByNewsId(Integer News_Id);
}
