package hqs.Service.Comments;

import hqs.Dao.CommentsDao;
import hqs.entity.Comments;
import hqs.entity.UserAndComments;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.swing.*;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class CommentsServiceImpl  implements  CommentsService{

    @Autowired
    private CommentsDao commentsDao;

    @Override
    public Integer creatComments(String Users_Id, Integer News_Id, Comments comments) {
          try {
              comments.setNews_Id(News_Id);
              comments.setUsers_Id(Users_Id);
              comments.setComment_Date(new Date());//日期自己写
              String uid = UUID.randomUUID().toString();
              comments.setExtraID(uid);
              return commentsDao.createComments(comments);

          }catch (Exception e)
          {
              System.out.println(e);
              return null;
          }

    }

    @Override
    public List<Comments> getAllComments() {
        return commentsDao.getAllComments();
    }

    @Override
    public List<UserAndComments> getAllCommentsV2() {
        try{
            return commentsDao.getAllCommentsV2();
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Integer deleteComment(String Users_Id, Integer News_Id,String uuid) {
       try {
           return commentsDao.deleteComment(Users_Id,News_Id,uuid);
       }catch (Exception e)
       {
           System.out.println(e);
           return null;
       }
    }

    @Override
    public List<UserAndComments> getAllCommentsByNewsId(Integer News_Id) {
        try {
            return  commentsDao.getAllCommentsByNewsId(News_Id);
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
}
