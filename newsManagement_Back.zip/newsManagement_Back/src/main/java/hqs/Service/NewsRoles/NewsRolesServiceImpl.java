package hqs.Service.NewsRoles;


import hqs.Dao.NewsRolesDao;
import hqs.Service.NewsRoles.NewsRolesService;
import hqs.entity.NewsRoles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;


@Service
public class NewsRolesServiceImpl implements NewsRolesService {

    @Autowired
    private NewsRolesDao newsRolesDao;//这里提示不需要理会

    //创建NewsRoles，并且使用唯一ID
    @Override
    public void createNewsRoles(NewsRoles newsRoles) {
        //使用唯一ID
        String id = UUID.randomUUID().toString().replace("-", "");
        newsRoles.setUsers_Id(id);
        newsRolesDao.createNewsRolers(newsRoles);
    }

    @Override
    public String getRole(String users_Id) {
        //这里出错的话直接返回
        try {
            return newsRolesDao.getRole(users_Id);
        }catch (Exception e)
        {
            System.out.println(e.toString());
             return null;
        }

    }
}
