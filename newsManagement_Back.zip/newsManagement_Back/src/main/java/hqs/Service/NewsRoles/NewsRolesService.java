package hqs.Service.NewsRoles;

import hqs.entity.NewsRoles;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;


public interface NewsRolesService {

    public void createNewsRoles(NewsRoles newsRoles);
    public String getRole( String users_Id);
}
