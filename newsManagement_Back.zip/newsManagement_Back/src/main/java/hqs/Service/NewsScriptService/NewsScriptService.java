package hqs.Service.NewsScriptService;

import hqs.entity.NewsScript;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface NewsScriptService {
    public void createNewsScript(NewsScript newsScript);
    public List<NewsScript> getAllNewsScript();
    public Integer updateNewsScriptById(NewsScript newsScript);
    public Integer  markIsPost (Integer News_Id, boolean mark);
}
