package hqs.Service.NewsScriptService;

import hqs.Dao.NewsScriptDao;
import hqs.Service.NewsRoles.NewsRolesService;
import hqs.entity.NewsScript;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NewsScriptServiceImpl implements NewsScriptService{

    @Autowired
    private NewsScriptDao newsScriptDao;

    @Override
    public void createNewsScript(NewsScript newsScript) {

         newsScriptDao.createNewsScript(newsScript);
//        System.out.println(newsScript.getNews_Id());
    }

    @Override
    public List<NewsScript> getAllNewsScript() {
       return newsScriptDao.getAllNewsScript();
    }

    @Override
    public Integer updateNewsScriptById(NewsScript newsScript) {
        try {
            return  newsScriptDao.updateNewsScriptById(newsScript);
        }catch (Exception e)
        {
            System.out.println(e);
            return  null;
        }
    }

    @Override
    public Integer markIsPost(Integer News_Id, boolean mark) {
        try {
            return newsScriptDao.markIsPost(News_Id,mark);
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
}
