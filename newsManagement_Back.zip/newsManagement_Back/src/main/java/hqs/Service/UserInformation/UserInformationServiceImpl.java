package hqs.Service.UserInformation;

import hqs.Dao.UserInformationDao;
import hqs.Service.NewsRoles.NewsRolesServiceImpl;
import hqs.entity.NewsRoles;
import hqs.entity.UserInformation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserInformationServiceImpl implements UserInformationService{

    @Autowired//先创建角色
    private NewsRolesServiceImpl newsRolesService;

    @Autowired
    private UserInformationDao userInformationDao;

    @Override
    public void createUserInformation(NewsRoles newsRoles, UserInformation userInformation) {

            newsRolesService.createNewsRoles(newsRoles);
            //获取UserId
            String id = newsRoles.getUsers_Id();
            userInformation.setUsers_Id(id);
        System.out.println(userInformation.getUsers_Id());

           userInformationDao.createUserInformation(userInformation);
    }

    @Override
    public List<UserInformation> getAllusersinformation() {
        return userInformationDao.getAllUserInformation();
    }

    @Override
    public UserInformation getUsersByAP(String account, String pwd) {
       try {
           return userInformationDao.getUsersByAP(account,pwd);
       }catch (Exception e)
       {
           System.out.println(e);
           return null;
       }
    }

    @Override
    public UserInformation getUserByID(String id) {
        try{
            return userInformationDao.getUserByID(id);
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Integer updateUserByID(UserInformation userInformation) {
        try {
            return userInformationDao.updateUserByID(userInformation);
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }

    }

    @Override
    public Boolean checkAbleToComment(String Users_Id) {
        try {
            return userInformationDao.checkAbleToComment(Users_Id);
        }catch (Exception e)
        {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Boolean checkIfAccountUnique(String User_Account) {
       try {
           return userInformationDao.checkIfAccountUnique(User_Account);
       }catch (Exception e)
       {
           System.out.println(e);
           return null;
       }
    }
}
