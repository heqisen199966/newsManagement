package hqs.Service.UserInformation;

import hqs.entity.NewsRoles;
import hqs.entity.UserInformation;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface UserInformationService {
    public void createUserInformation(NewsRoles newsRoles, UserInformation userInformation);
    public List<UserInformation> getAllusersinformation();
    public UserInformation getUsersByAP( String account, String pwd);
    public UserInformation getUserByID(String id);
    public Integer updateUserByID(UserInformation userInformation);
    public Boolean checkAbleToComment(String Users_Id);//是否禁言
    public Boolean checkIfAccountUnique(String User_Account);//注册时需要账号唯一
}
