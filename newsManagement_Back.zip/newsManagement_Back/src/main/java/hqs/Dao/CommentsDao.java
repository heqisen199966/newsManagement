package hqs.Dao;

import hqs.entity.Comments;
import hqs.entity.UserAndComments;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.PutMapping;

import java.util.List;

public interface CommentsDao {

    public Integer createComments(Comments comments);
    public List<Comments> getAllComments();
    public List<UserAndComments> getAllCommentsV2();
    public List<UserAndComments> getAllCommentsByNewsId(Integer News_Id);
    public Integer deleteComment(@Param("Users_Id") String Users_Id, @Param("News_Id") Integer News_Id,@Param("uuid") String uuid);

}
