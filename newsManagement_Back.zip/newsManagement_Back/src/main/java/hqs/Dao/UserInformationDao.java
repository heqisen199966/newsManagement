package hqs.Dao;

import hqs.entity.UserInformation;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserInformationDao {
    public void createUserInformation(UserInformation userInformation);
    public List<UserInformation> getAllUserInformation();
    public UserInformation getUsersByAP(@Param("account") String account, @Param("pwd") String pwd);
    public UserInformation getUserByID(String id);
    public Integer updateUserByID(UserInformation userInformation);
    public Boolean checkAbleToComment(String Users_Id);//是否禁言
    public Boolean checkIfAccountUnique(String User_Account);//注册时需要账号唯一
}
