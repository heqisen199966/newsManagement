package hqs.Dao;

import hqs.entity.NewsRoles;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

//在主入口扫描mapper

public interface NewsRolesDao {

    public void createNewsRolers(NewsRoles newsRoles);
    public String getRole(@Param("users_Id") String users_Id);

}
