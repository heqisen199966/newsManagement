package hqs.Dao;

import hqs.entity.NewsScript;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface NewsScriptDao {

    public  void createNewsScript(NewsScript newsScript);
    public List<NewsScript> getAllNewsScript();
    public Integer updateNewsScriptById(NewsScript newsScript);
    //修改是否发布状态
    public Integer  markIsPost(@Param("id") Integer News_Id, @Param("mark") boolean mark);
}
