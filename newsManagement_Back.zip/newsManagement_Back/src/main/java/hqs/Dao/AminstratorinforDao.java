package hqs.Dao;

import hqs.entity.Adminstratorinfor;
import hqs.entity.NewsRoles;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AminstratorinforDao {
    public void createAminstratorinfor(Adminstratorinfor adminstratorinfor);
    public List<Adminstratorinfor> getAllAdminstratorinfor();
    //数据多于一个时要指定它的别名
    public Adminstratorinfor getAdminByAP(@Param("account") String account, @Param("pwd") String pwd);
    public  Adminstratorinfor getAdminByID(String id);
    public Integer updateAdminByID(Adminstratorinfor adminstratorinfor);

}
