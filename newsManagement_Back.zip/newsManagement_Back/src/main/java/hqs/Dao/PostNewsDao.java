package hqs.Dao;

import hqs.entity.PostNews;
import hqs.entity.ShowingNews;

import java.util.List;

public interface PostNewsDao {
    public void  createPostNews(PostNews postNews);
    public List<PostNews> getAllPostNews();
    public PostNews getPostNewsByNewsID(Integer newsId);
    public Integer updatePostNewsByID(PostNews postNews);
    public  Integer deletePostNewsById(Integer News_Id);
//  这里拿的是展示出来数据，要使用另外的POJO
    public List<ShowingNews> getPostNewsByGenre(String genre);

//    增加阅读次数
    public   Integer addViewsByID(Integer  News_Id);
//    专门拿出首页的函数
    public List<ShowingNews> getHomePagePostNews(String homepage);

//   新闻标题,简介，关键字 模糊搜索新闻,名字这里起的有误导
public List<ShowingNews> getNewsByHeadLine(String HeadLine);

}
