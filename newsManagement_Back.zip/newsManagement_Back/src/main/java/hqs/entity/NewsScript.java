package hqs.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class NewsScript {
    private Integer News_Id;
    private String News_Editor;
    private String News_Content;
    private String PicPath;
    private String ClipsPath;
    private Date News_HandlingDate;
    private String News_Headline;
    private String Outline;
    private Boolean IsPost;
}
