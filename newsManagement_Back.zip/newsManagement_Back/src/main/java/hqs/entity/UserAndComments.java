package hqs.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

//这个用于发给前端封装的数据，
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UserAndComments {
//
    private String Users_Id;
    private String User_Name;
    private boolean User_IsComment;
    private Integer News_Id;
    private String News_Headline;
    private String Comment_Content;
    private Date Comment_Date;
    private String ExtraID;

}
