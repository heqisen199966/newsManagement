package hqs.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Comments {
    private String Users_Id;
    private Integer News_Id;
    private String Comment_Content;
    private Date Comment_Date;
    private String ExtraID;//后来才发现一个人在同一篇新闻下只能评论一次，数据库设计失误
}
