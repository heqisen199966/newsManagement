package hqs.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PostNews {
    private String Users_Id;
    private Integer News_Id;
    private String News_KeyWords;
    private Date  News_PostDate;
    private Integer News_Views;
    private String News_Genre;
    private  String News_Section;
    private   Integer News_Sequence;
}
