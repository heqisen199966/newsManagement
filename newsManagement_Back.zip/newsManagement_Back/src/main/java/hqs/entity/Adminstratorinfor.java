package hqs.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Adminstratorinfor {

    private String Users_Id;
    private String Admin_Account;
    private String Admin_Pwd;
    private String Admin_Name;

    public Adminstratorinfor(String admin_Account, String admin_Pwd, String admin_Name) {
        Admin_Account = admin_Account;
        Admin_Pwd = admin_Pwd;
        Admin_Name = admin_Name;
    }
}
