package hqs.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
//这里用于给前台最终展示的数据
public class ShowingNews {

    private Integer News_Id;
    private String News_Editor;
    private String News_Content;
    private String PicPath;
    private String ClipsPath;
    private String News_Headline;
    private String Outline;

    private String News_KeyWords;
    private Date  News_PostDate;
    private Integer News_Views;
    private String News_Genre;
    private  String News_Section;
    private   Integer News_Sequence;
}
