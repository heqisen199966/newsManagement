package hqs.entity;

//单实例，由于不同控制器session获取会不一样，redis还没学，利用单实例这个先充当拿数据，

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class FrontData {
    private String role;
}
