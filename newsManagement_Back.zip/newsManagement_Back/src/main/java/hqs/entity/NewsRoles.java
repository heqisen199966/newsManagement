package hqs.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

//下面是lombok语法，设置getter,setter,toString,有参无参构造
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NewsRoles {
    private String Users_Id;
    private String  Role;

    public NewsRoles(String role){
            this.Role = role;
    }
}
