package hqs.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserInformation {
    private  String Users_Id;
    private  String User_Account;
    private  String User_Pwd;
    private  String User_Name;
    private  boolean User_IsComment;
    private  boolean User_Status;


}
