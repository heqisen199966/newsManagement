package hqs.ConfigEntity;

import hqs.entity.FrontData;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class MapEntity {

    @Bean(value = "conMap")//向IOC容器注入map，用于返回给前端
    public Map<String,Object> createMap()
    {
        return new HashMap<>();
    }


}
